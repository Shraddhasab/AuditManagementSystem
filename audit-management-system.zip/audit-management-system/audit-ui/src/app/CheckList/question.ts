export interface Question {
    questionId: number;
    question: string;
    auditType: string;
    response:string;
}