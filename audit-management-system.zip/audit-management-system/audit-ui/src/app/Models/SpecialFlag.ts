export class SpecialFLag{
    public flag:boolean=false;
    constructor(){}
}