INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (1, 'Harsh kumar', 'hk', 'hk000', 'Project-1');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (2, 'Divyam kumar', 'dk', 'dk000', 'Project-2');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (3, 'utkarsha patil', 'up', 'up000', 'Project-3');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (4, 'shraddha sable', 'ss', 'ss000', 'Project-4');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (5, 'Muabark lepakshi', 'ml', 'ml000', 'Project-5');